chrome.runtime.onInstalled.addListener(() => {
  console.log("Sign Language Interpreter Extension Installed");
});
