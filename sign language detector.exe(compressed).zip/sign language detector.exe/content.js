// Import Three.js and GLTFLoader
import * as THREE from "https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.module.min.js";
import { GLTFLoader } from "https://cdn.jsdelivr.net/npm/three/examples/jsm/loaders/GLTFLoader.js";

// Load the TensorFlow.js model
async function loadModel() {
  return await tf.loadLayersModel(chrome.runtime.getURL("tfjs_model/model.json"));
}

// Extract subtitles from the video
function extractSubtitles() {
  let subtitles = document.querySelector(".ytp-caption-segment"); // YouTube
  if (!subtitles) {
    subtitles = document.querySelector(".player-timedtext-text-container"); // Netflix
  }
  return subtitles ? subtitles.innerText : null;
}

// Load and display the avatar
function loadAvatar() {
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
  const renderer = new THREE.WebGLRenderer({ alpha: true });

  renderer.setSize(300, 300);
  document.body.appendChild(renderer.domElement);

  const loader = new GLTFLoader();
  loader.load(chrome.runtime.getURL("avatar.glb"), (gltf) => {
    window.avatar = gltf.scene;
    scene.add(window.avatar);
    camera.position.z = 5;

    function animate() {
      requestAnimationFrame(animate);
      renderer.render(scene, camera);
    }
    animate();
  });
}

// Process subtitles and update the avatar
async function processText(text) {
  if (!text) return;
  const model = await loadModel();
  const inputTensor = tf.tensor([[text.length]]); // Convert text to tensor (modify as needed)
  const output = model.predict(inputTensor);
  applyKeypointsToAvatar(output.dataSync());
}

// Apply keypoints to the avatar
function applyKeypointsToAvatar(keypoints) {
  if (!window.avatar) return;
  window.avatar.traverse((bone) => {
    if (bone.isBone) {
      bone.rotation.x = keypoints[0]; // Adjust according to your model
      bone.rotation.y = keypoints[1];
      bone.rotation.z = keypoints[2];
    }
  });
}

// Start processing subtitles every 500ms
setInterval(() => {
  const text = extractSubtitles();
  processText(text);
}, 500);

// Load the avatar when the extension is activated
loadAvatar();
