import pandas as pd 
import numpy as np 
import os 
import librosa 
import librosa.display
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize 
from transformers import BertTokenizer, BertModel
import torch
import tensorflow as tf
from tensorflow.keras.layers import LSTM, Dense, Input    # type: ignore
from tensorflow.keras.models import Model   # type: ignore

nltk.download('stopwords')
nltk.download('punkt_tab')

stopwords = set(stopwords.words('english'))

data_path = r'C:\Users\Hp\OneDrive\Documents\audio'

text_files = sorted([f for f in os.listdir(data_path) if f.endswith('.txt')])
audio_files = sorted([f for f in os.listdir(data_path) if f.endswith('.wav')])

cleaned_sentences = []
gloss_text = []

def remove_stopwords(transcription):
    words = word_tokenize(transcription)
    filtered = [word for word in words if word.lower() not in stopwords]
    return" ".join(filtered)  

def text_to_gloss(sentence):
        gloss_dict = {
        "I": "I", "am": "", "you": "YOU", "he": "HE", "she": "SHE", "we": "WE", "they": "THEY",
        "is": "", "are": "", "was": "", "were": "", "be": "", "been": "", "being": "",
        "going": "GO", "to": "", "school": "SCHOOL", "tomorrow": "TOMORROW",
        "eat": "EAT", "drink": "DRINK", "want": "WANT", "need": "NEED", "help": "HELP",
        "love": "LOVE", "work": "WORK", "stop": "STOP", "start": "START", "come": "COME",
        "go": "GO", "can": "CAN", "cannot": "CAN'T", "know": "KNOW", "don't": "DON'T",
        "understand": "UNDERSTAND", "think": "THINK", "remember": "REMEMBER", 
        "forget": "FORGET", "wait": "WAIT", "look": "LOOK", "see": "SEE", "talk": "TALK",
        "listen": "LISTEN", "happy": "HAPPY", "sad": "SAD", "angry": "ANGRY",
        "good": "GOOD", "bad": "BAD", "fast": "FAST", "slow": "SLOW", "big": "BIG", "small": "SMALL",
        "yes": "YES", "no": "NO", "thank you": "THANK-YOU", "please": "PLEASE",
        "excuse me": "EXCUSE-ME", "sorry": "SORRY", "hello": "HELLO", "goodbye": "GOODBYE","Gaia":"GAIA", "avaliable":"AVAILABLE"
        }
        words = word_tokenize(sentence)
        gloss_words = [gloss_dict.get(word.lower(), word.upper().upper())for word in words]
        return" ".join(filter(None, gloss_words))


for t, a in zip(text_files, audio_files):
    text_path = os.path.join(data_path, t)
    audio_path = os.path.join(data_path, a)
    
    with open(text_path, 'r', encoding = 'utf-8') as f: 
        transcription = f.read().strip().split("\t")[-1]
        cleaned_sentences.append(remove_stopwords(transcription))
       
        
for i, sentence in enumerate(cleaned_sentences, 1):   

 gloss_text.append(text_to_gloss(sentence))
 
    
y , sr = librosa.load(audio_path, sr = 16000)
mfcc = librosa.feature.mfcc(y = y, sr = sr, n_mfcc = 13)

'''
plt.figure(figsize = (10, 4))
librosa.display.specshow(mfcc, x_axis = 'time', cmap = 'coolwarm')
plt.colorbar(label = 'Intensity')
plt.title('Time vs coefficients')
plt.xlabel('Time')
plt.ylabel('Coefficients')
plt.show()
'''
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
bert_model = BertModel.from_pretrained('bert-base-uncased')

def get_text_embeddings():
    inputs = tokenizer(gloss_text, return_tensors = 'pt', padding = True, truncation = True)
    outputs = bert_model(**inputs)
    return outputs.last_hidden_state[:, 0, :].detach().numpy()

def get_audio_embeddings():
        y , sr = librosa.load(audio_path, sr = 16000)
        mfcc = librosa.feature.mfcc(y = y, sr = sr, n_mfcc = 13)
        return np.mean(mfcc, axis = 1)

text_embeddings = get_text_embeddings()
audio_embeddings = get_audio_embeddings()

min_size = min(text_embeddings.shape[0], audio_embeddings.shape[0]) 
text_embeddings = text_embeddings[:min_size]
audio_embeddings = audio_embeddings[:min_size]

combined_input = np.hstack([text_embeddings, np.expand_dims(audio_embeddings, axis = 1)])

X_input = combined_input.reshape(1, 13, 769)

input_layer = Input(shape =(None, 769))
x = LSTM(128, return_sequences = True)(input_layer)
x = LSTM(64, return_sequences = True)(x)
output_layer = Dense(150, activation = 'linear')(x)

model = Model(inputs = input_layer, outputs = output_layer)
model.compile(optimizer = 'adam', loss = 'mse')

model.summary()

result = model.predict(X_input)

lstm = result.squeeze(0)
lstm_outputs = lstm.reshape(13, 75, 2)

def reshape_to_keypoints(lstm_outputs):
    keypoints = lstm_outputs.reshape(-1, 2)
    return keypoints
